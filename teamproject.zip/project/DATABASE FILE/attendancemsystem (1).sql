-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2023 at 03:06 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendancemsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `Id` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`Id`, `firstName`, `lastName`, `emailAddress`, `password`) VALUES
(3, 'dctr', '8213', 'dctr@mail.com', 'dctr@8213');

-- --------------------------------------------------------

--
-- Table structure for table `tblattendance`
--

CREATE TABLE `tblattendance` (
  `Id` int(10) NOT NULL,
  `admissionNo` varchar(255) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `sessionTermId` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `dateTimeTaken` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblattendance`
--

INSERT INTO `tblattendance` (`Id`, `admissionNo`, `classId`, `classArmId`, `sessionTermId`, `status`, `dateTimeTaken`) VALUES
(211, '21a31a0577', '5', '11', '1', '1', '2023-04-05'),
(210, '21a31a0569', '5', '11', '1', '1', '2023-04-04'),
(209, '21a31a0570', '5', '11', '1', '1', '2023-04-04'),
(208, '21a31a0568', '5', '11', '1', '1', '2023-04-04'),
(207, '21a31a0567', '5', '11', '1', '1', '2023-04-04'),
(206, '21a31a0571', '5', '11', '1', '1', '2023-04-04'),
(205, '21a31a0572', '5', '11', '1', '1', '2023-04-04'),
(204, '21a31a0573', '5', '11', '1', '1', '2023-04-04'),
(203, '21a31a0574', '5', '11', '1', '1', '2023-04-04'),
(202, '21a31a0575', '5', '11', '1', '1', '2023-04-04'),
(201, '21a31a0576', '5', '11', '1', '1', '2023-04-04'),
(200, '21a31a0577', '5', '11', '1', '1', '2023-04-04'),
(199, '21a31a05b6', '5', '11', '1', '1', '2023-04-03'),
(222, '21a31a0577', '5', '11', '1', '1', '2023-04-06'),
(193, 'AMS151', '4', '6', '1', '0', '2021-10-07'),
(194, 'AMS159', '4', '6', '1', '0', '2021-10-07'),
(195, 'AMS161', '4', '6', '1', '0', '2021-10-07'),
(196, 'AMS005', '1', '2', '1', '0', '2023-04-03'),
(197, 'AMS007', '1', '2', '1', '0', '2023-04-03'),
(198, 'AMS011', '1', '2', '1', '0', '2023-04-03'),
(212, '21a31a0576', '5', '11', '1', '1', '2023-04-05'),
(213, '21a31a0575', '5', '11', '1', '1', '2023-04-05'),
(214, '21a31a0574', '5', '11', '1', '1', '2023-04-05'),
(215, '21a31a0573', '5', '11', '1', '1', '2023-04-05'),
(216, '21a31a0572', '5', '11', '1', '1', '2023-04-05'),
(217, '21a31a0571', '5', '11', '1', '1', '2023-04-05'),
(218, '21a31a0567', '5', '11', '1', '1', '2023-04-05'),
(219, '21a31a0568', '5', '11', '1', '1', '2023-04-05'),
(220, '21a31a0570', '5', '11', '1', '1', '2023-04-05'),
(221, '21a31a0569', '5', '11', '1', '1', '2023-04-05'),
(223, '21a31a0576', '5', '11', '1', '1', '2023-04-06'),
(224, '21a31a0575', '5', '11', '1', '1', '2023-04-06'),
(225, '21a31a0574', '5', '11', '1', '1', '2023-04-06'),
(226, '21a31a0573', '5', '11', '1', '1', '2023-04-06'),
(227, '21a31a0572', '5', '11', '1', '1', '2023-04-06'),
(228, '21a31a0571', '5', '11', '1', '1', '2023-04-06'),
(229, '21a31a0567', '5', '11', '1', '1', '2023-04-06'),
(230, '21a31a0568', '5', '11', '1', '1', '2023-04-06'),
(231, '21a31a0570', '5', '11', '1', '1', '2023-04-06'),
(232, '21a31a0569', '5', '11', '1', '1', '2023-04-06'),
(233, '21a31a0533', '5', '10', '1', '0', '2023-04-06'),
(234, '21a31a0577', '5', '11', '1', '1', '2023-04-07'),
(235, '21a31a0576', '5', '11', '1', '1', '2023-04-07'),
(236, '21a31a0575', '5', '11', '1', '1', '2023-04-07'),
(237, '21a31a0574', '5', '11', '1', '1', '2023-04-07'),
(238, '21a31a0573', '5', '11', '1', '1', '2023-04-07'),
(239, '21a31a0572', '5', '11', '1', '1', '2023-04-07'),
(240, '21a31a0571', '5', '11', '1', '1', '2023-04-07'),
(241, '21a31a0567', '5', '11', '1', '1', '2023-04-07'),
(242, '21a31a0568', '5', '11', '1', '1', '2023-04-07'),
(243, '21a31a0570', '5', '11', '1', '1', '2023-04-07'),
(244, '21a31a0569', '5', '11', '1', '1', '2023-04-07'),
(245, '21a31a0579', '5', '11', '1', '1', '2023-04-07'),
(246, '21a31a0580', '5', '11', '1', '1', '2023-04-07'),
(247, '21a31a0581', '5', '11', '1', '1', '2023-04-07'),
(248, '21a31a0582', '5', '11', '1', '1', '2023-04-07'),
(249, '21a31a0583', '5', '11', '1', '1', '2023-04-07'),
(250, '21a31a0584', '5', '11', '1', '1', '2023-04-07'),
(251, '21a31a0585', '5', '11', '1', '1', '2023-04-07'),
(252, '21a31a0586', '5', '11', '1', '1', '2023-04-07'),
(253, '21a31a0587', '5', '11', '1', '1', '2023-04-07'),
(254, '21a31a0588', '5', '11', '1', '1', '2023-04-07'),
(255, '21a31a0589', '5', '11', '1', '1', '2023-04-07'),
(256, '21a31a0590', '5', '11', '1', '1', '2023-04-07'),
(257, '21a31a0591', '5', '11', '1', '1', '2023-04-07'),
(258, '21a31a0592', '5', '11', '1', '1', '2023-04-07'),
(259, '21a31a0593', '5', '11', '1', '1', '2023-04-07'),
(260, '21a31a0594', '5', '11', '1', '1', '2023-04-07'),
(261, '21a31a0595', '5', '11', '1', '1', '2023-04-07'),
(262, '21a31a0596', '5', '11', '1', '1', '2023-04-07'),
(263, '21a31a0597', '5', '11', '1', '1', '2023-04-07'),
(264, '21a31a0598', '5', '11', '1', '1', '2023-04-07'),
(265, '21a31a0599', '5', '11', '1', '1', '2023-04-07'),
(266, '21a31a05a0', '5', '11', '1', '1', '2023-04-07'),
(267, '21a31a05a1', '5', '11', '1', '1', '2023-04-07'),
(268, '21a31a05a2', '5', '11', '1', '1', '2023-04-07'),
(269, '21a31a05a3', '5', '11', '1', '1', '2023-04-07'),
(270, '21a31a05a4', '5', '11', '1', '1', '2023-04-07'),
(271, '21a31a05a5', '5', '11', '1', '1', '2023-04-07'),
(272, '21a31a05a6', '5', '11', '1', '1', '2023-04-07'),
(273, '21a31a05a7', '5', '11', '1', '1', '2023-04-07'),
(274, '21a31a05a8', '5', '11', '1', '1', '2023-04-07'),
(275, '21a31a05a9', '5', '11', '1', '1', '2023-04-07'),
(276, '21a31a05b0', '5', '11', '1', '1', '2023-04-07'),
(277, '21a31a05b1', '5', '11', '1', '1', '2023-04-07'),
(278, '21a31a05b2', '5', '11', '1', '1', '2023-04-07'),
(279, '21a31a05b3', '5', '11', '1', '1', '2023-04-07'),
(280, '21a31a05b4', '5', '11', '1', '1', '2023-04-07'),
(281, '21a31a05b5', '5', '11', '1', '1', '2023-04-07'),
(282, '21a31a05b6', '5', '11', '1', '1', '2023-04-07'),
(283, '21a31a05b7', '5', '11', '1', '1', '2023-04-07'),
(284, '21a31a05b8', '5', '11', '1', '1', '2023-04-07'),
(285, '21a31a05b9', '5', '11', '1', '1', '2023-04-07'),
(286, '21a31a05c0', '5', '11', '1', '1', '2023-04-07'),
(287, '21a31a05c1', '5', '11', '1', '1', '2023-04-07'),
(288, '21a31a05c2', '5', '11', '1', '1', '2023-04-07'),
(289, '21a31a05c3', '5', '11', '1', '1', '2023-04-07'),
(290, '21a31a05c4', '5', '11', '1', '1', '2023-04-07'),
(291, '21a31a05c5', '5', '11', '1', '1', '2023-04-07'),
(292, '21a31a05c6', '5', '11', '1', '1', '2023-04-07'),
(293, '21a31a05c7', '5', '11', '1', '1', '2023-04-07'),
(294, '21a31a05c8', '5', '11', '1', '1', '2023-04-07'),
(295, '21a31a05c9', '5', '11', '1', '1', '2023-04-07'),
(296, '21a31a05d0', '5', '11', '1', '1', '2023-04-07'),
(297, '21a31a05d1', '5', '11', '1', '1', '2023-04-07'),
(298, '21a31a05d2', '5', '11', '1', '1', '2023-04-07'),
(299, '22a35a0508', '5', '11', '1', '1', '2023-04-07'),
(300, '22a35a0509', '5', '11', '1', '1', '2023-04-07'),
(301, '22a35a0510', '5', '11', '1', '1', '2023-04-07'),
(302, '22a35a0511', '5', '11', '1', '1', '2023-04-07'),
(303, '22a35a0512', '5', '11', '1', '1', '2023-04-07'),
(304, '22a35a0513', '5', '11', '1', '1', '2023-04-07'),
(305, '22a35a0514', '5', '11', '1', '1', '2023-04-07');

-- --------------------------------------------------------

--
-- Table structure for table `tblclass`
--

CREATE TABLE `tblclass` (
  `Id` int(10) NOT NULL,
  `className` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblclass`
--

INSERT INTO `tblclass` (`Id`, `className`) VALUES
(7, 'AI'),
(6, 'AI&ML'),
(5, 'CSE'),
(8, 'Data science'),
(9, 'EEE'),
(10, 'ECE'),
(11, 'MECH'),
(12, 'CIVIL');

-- --------------------------------------------------------

--
-- Table structure for table `tblclassarms`
--

CREATE TABLE `tblclassarms` (
  `Id` int(10) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmName` varchar(255) NOT NULL,
  `isAssigned` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblclassarms`
--

INSERT INTO `tblclassarms` (`Id`, `classId`, `classArmName`, `isAssigned`) VALUES
(12, '5', '2-c', '0'),
(11, '5', '2-b', '1'),
(10, '5', '2-a', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tblclassteacher`
--

CREATE TABLE `tblclassteacher` (
  `Id` int(10) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `emailAddress` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phoneNo` varchar(50) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblclassteacher`
--

INSERT INTO `tblclassteacher` (`Id`, `firstName`, `lastName`, `emailAddress`, `password`, `phoneNo`, `classId`, `classArmId`, `dateCreated`) VALUES
(11, 'CR', 'cse-a', 'csea@mail.com', 'pass123', '', '5', '10', '2023-04-06'),
(10, 'CR', 'cse-b', 'cseb@mail.com', 'pass123', '', '5', '11', '2023-04-03');

-- --------------------------------------------------------

--
-- Table structure for table `tblsessionterm`
--

CREATE TABLE `tblsessionterm` (
  `Id` int(10) NOT NULL,
  `sessionName` varchar(50) NOT NULL,
  `termId` varchar(50) NOT NULL,
  `isActive` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblsessionterm`
--

INSERT INTO `tblsessionterm` (`Id`, `sessionName`, `termId`, `isActive`, `dateCreated`) VALUES
(1, '2019/2020', '1', '1', '2020-10-31'),
(3, '2019/2020', '2', '0', '2020-10-31');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `Id` int(10) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `admissionNumber` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`Id`, `firstName`, `lastName`, `admissionNumber`, `password`, `classId`, `classArmId`, `dateCreated`) VALUES
(33, 'M.chandini', 'Apoorva', '21a31a0567', '12345', '5', '11', '2023-04-03'),
(32, 'Manaswini', 'Balla', '21a31a0568', '12345', '5', '11', '2023-04-03'),
(31, 'Sri Harisha', 'Busi', '21a31a0569', '12345', '5', '11', '2023-04-03'),
(30, 'Pavani Ratna Sri Santhoshi', 'Challa', '21a31a0570', '12345', '5', '11', '2023-04-03'),
(29, 'Aishwarya', 'Cheekurumalli', '21a31a0571', '12345', '5', '11', '2023-04-03'),
(28, 'Bhavitha Reddy', 'Chinta', '21a31a0572', '12345', '5', '11', '2023-04-03'),
(27, 'Lakshmi Surya Vaishnavi', 'Damisetti', '21a31a0573', '12345', '5', '11', '2023-04-03'),
(23, 'V.V.R.Lakshmi Priya', 'Gollapudi', '21a31a0574', '12345', '5', '11', '2023-04-03'),
(24, 'Poojitha', 'Gandikota', '21a31a0575', '12345', '5', '11', '2023-04-03'),
(26, 'Varshita', 'Kintali', '21a31a0576', '12345', '5', '11', '2023-04-03'),
(25, 'Usha Sri Lakshmi', 'Kondumahanthi', '21a31a0577', '12345', '5', '11', '2023-04-03'),
(102, 'uday', 'joga', '1', '12345', '5', '10', '2023-04-06'),
(41, 'Lakshmi Meghana', 'Chekka', '21a31a0579', '12345', '5', '11', '2023-04-06'),
(42, 'Lakshmi Saranya', 'Koyyalamudi', '21a31a0580', '12345', '5', '11', '2023-04-06'),
(43, 'Sri Krishna Sai Mahalakshmi ', 'Madugula', '21a31a0581', '12345', '5', '11', '2023-04-06'),
(44, 'Mayukha', 'Vundavalli', '21a31a0582', '12345', '5', '11', '2023-04-06'),
(45, 'Praharshini Sowmya Sri Lakshmi', 'Meka', '21a31a0583', '12345', '5', '11', '2023-04-06'),
(46, 'Parimala Jyothi', 'Muliki', '21a31a0584', '12345', '5', '11', '2023-04-06'),
(47, 'Gayatri', 'Murthyneedi', '21a31a0585', '12345', '5', '11', '2023-04-06'),
(48, 'Hema Vara Sanjeevi', 'Nama', '21a31a0586', '12345', '5', '11', '2023-04-06'),
(49, 'Harshitha', 'Naragana', '21a31a0587', '12345', '5', '11', '2023-04-06'),
(50, 'Nikitha', 'Palakurthi', '21a31a0588', '12345', '5', '11', '2023-04-06'),
(51, 'Rama Swathi', 'Nulu', '21a31a0589', '12345', '5', '11', '2023-04-06'),
(52, 'Navya Nalini', 'Penugula', '21a31a0590', '12345', '5', '11', '2023-04-06'),
(53, 'Santhi Meghana', 'Penumarthi', '21a31a0591', '12345', '5', '11', '2023-04-06'),
(54, 'Tejaswini', 'Pinapothu', '21a31a0592', '12345', '5', '11', '2023-04-06'),
(55, 'Navya Sumanvitha', 'Rapaka', '21a31a0593', '12345', '5', '11', '2023-04-06'),
(56, 'Sai Satya Navya Sri', 'Vasamsetti', '21a31a0594', '12345', '5', '11', '2023-04-06'),
(57, 'Sri Sai Akshitha', 'Manepalli', '21a31a0595', '12345', '5', '11', '2023-04-06'),
(58, 'Lakshmi Tanmayi', 'Tadala', '21a31a0596', '12345', '5', '11', '2023-04-06'),
(59, 'Renuka', 'Thammana', '21a31a0597', '12345', '5', '11', '2023-04-06'),
(60, 'Neha Sai Chandrika', 'Vundi', '21a31a0598', '12345', '5', '11', '2023-04-06'),
(61, 'Reshma Chowdary', 'Yarlagadda', '21a31a0599', '12345', '5', '11', '2023-04-06'),
(62, 'Satya Sri Sowjanya', 'Yarra', '21a31a05a0', '12345', '5', '11', '2023-04-06'),
(63, 'Thanusha Devi Sharmista', 'Yarra', '21a31a05a1', '12345', '5', '11', '2023-04-06'),
(64, 'Jeswanth Sai', 'Aithabathula', '21a31a05a2', '12345', '5', '11', '2023-04-06'),
(65, 'Sri Krishna Tarun', 'Bejavada', '21a31a05a3', '12345', '5', '11', '2023-04-06'),
(66, 'Abhinav Kartheek Reddy', 'Billakurthi', '21a31a05a4', '12345', '5', '11', '2023-04-06'),
(67, 'Dinesh Reddy', 'Chejarla', '21a31a05a5', '12345', '5', '11', '2023-04-06'),
(68, 'Sai Ramakrishna', 'Chintala', '21a31a05a6', '12345', '5', '11', '2023-04-06'),
(69, 'Vamsi Vardhan', 'Peddisetti', '21a31a05a7', '12345', '5', '11', '2023-04-06'),
(70, 'Jayakumar ', 'Gada', '21a31a05a8', '12345', '5', '11', '2023-04-06'),
(71, 'Venkatesh', 'Gisala', '21a31a05a9', '12345', '5', '11', '2023-04-06'),
(72, 'Victor Roy', 'Injey', '21a31a05b0', '12345', '5', '11', '2023-04-06'),
(73, 'Harish Ganapathi', 'Kadiyam', '21a31a05b1', '12345', '5', '11', '2023-04-06'),
(74, 'Ajay Sai Prasan', 'Kapu', '21a31a05b2', '12345', '5', '11', '2023-04-06'),
(75, 'Ram Sai Venkata Durga Prasad', 'koneti', '21a31a05b3', '12345', '5', '11', '2023-04-06'),
(76, 'Veera venkata Satyanarayana Reddy', 'Kovvuri', '21a31a05b4', '12345', '5', '11', '2023-04-06'),
(77, 'Kesava Naga Satya Manikanta', 'Mallavarapu', '21a31a05b5', '12345', '5', '11', '2023-04-06'),
(78, 'Sriram Chowdary', 'Marni', '21a31a05b6', '12345', '5', '11', '2023-04-06'),
(79, 'Srikar Surya Narayana Chowdary', 'Mulagada', '21a31a05b7', '12345', '5', '11', '2023-04-06'),
(80, 'Chinna Venkata Chaitanya', 'Padamati', '21a31a05b8', '12345', '5', '11', '2023-04-06'),
(81, 'Venkata Raghunandan', 'Penke', '21a31a05b9', '12345', '5', '11', '2023-04-06'),
(82, 'Avinash', 'Pulletikurthi', '21a31a05c0', '12345', '5', '11', '2023-04-06'),
(83, 'V.Koushik', 'Punyamurthula', '21a31a05c1', '12345', '5', '11', '2023-04-06'),
(84, 'Surya Sai Venkata Prasad', 'Ravula', '21a31a05c2', '12345', '5', '11', '2023-04-06'),
(85, 'Murali Srinivas', '', '21a31a05c3', '12345', '5', '11', '2023-04-06'),
(86, 'Vamsi ', 'Reddy', '21a31a05c4', '12345', '5', '11', '2023-04-06'),
(87, 'Pavan Satya Pranudh', 'Revuri', '21a31a05c5', '12345', '5', '11', '2023-04-06'),
(88, 'Ayyaz', 'Shaik', '21a31a05c6', '12345', '5', '11', '2023-04-06'),
(89, 'Moulaali', 'Shaik', '21a31a05c7', '12345', '5', '11', '2023-04-06'),
(90, 'Sadik Sameer', 'Shaik', '21a31a05c8', '12345', '5', '11', '2023-04-06'),
(91, 'Satheesh', 'Ulamparthi', '21a31a05c9', '12345', '5', '11', '2023-04-06'),
(92, 'S.V.Jagadeeshwar', 'Vanaparthi', '21a31a05d0', '12345', '5', '11', '2023-04-06'),
(93, 'Rajesh', 'Vardhineedi', '21a31a05d1', '12345', '5', '11', '2023-04-06'),
(94, 'Sai Sumanth', 'Yedla', '21a31a05d2', '12345', '5', '11', '2023-04-06'),
(95, 'Sudha', 'Boddu', '22a35a0508', '12345', '5', '11', '2023-04-06'),
(96, 'Jayasri', 'Kaladi', '22a35a0509', '12345', '5', '11', '2023-04-06'),
(97, 'jayalakshmi', 'Penke', '22a35a0510', '12345', '5', '11', '2023-04-06'),
(98, 'Chandu Praveen', 'Balasadi', '22a35a0511', '12345', '5', '11', '2023-04-06'),
(99, 'Srinivasu', 'Gunnam', '22a35a0512', '12345', '5', '11', '2023-04-06'),
(100, 'Sasi Kumar', 'Kilari', '22a35a0513', '12345', '5', '11', '2023-04-06'),
(101, 'Satish Kumar', 'Tatapudi', '22a35a0514', '12345', '5', '11', '2023-04-06'),
(103, 'Divya ', 'Kotipalli', '21a31a0578', '12345', '5', '11', '2023-04-07');

-- --------------------------------------------------------

--
-- Table structure for table `tblterm`
--

CREATE TABLE `tblterm` (
  `Id` int(10) NOT NULL,
  `termName` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblterm`
--

INSERT INTO `tblterm` (`Id`, `termName`) VALUES
(1, 'First'),
(2, 'Second'),
(3, 'Third');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblattendance`
--
ALTER TABLE `tblattendance`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblclass`
--
ALTER TABLE `tblclass`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblclassarms`
--
ALTER TABLE `tblclassarms`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblclassteacher`
--
ALTER TABLE `tblclassteacher`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblsessionterm`
--
ALTER TABLE `tblsessionterm`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblterm`
--
ALTER TABLE `tblterm`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblattendance`
--
ALTER TABLE `tblattendance`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=306;

--
-- AUTO_INCREMENT for table `tblclass`
--
ALTER TABLE `tblclass`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblclassarms`
--
ALTER TABLE `tblclassarms`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblclassteacher`
--
ALTER TABLE `tblclassteacher`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblsessionterm`
--
ALTER TABLE `tblsessionterm`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `tblterm`
--
ALTER TABLE `tblterm`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
